# Define the phone directory as a dictionary
phone_directory = {
    "Amal": "1111111111",
    "Mohammed": "2222222222",
    "Khadijah": "3333333333",
    "Abdullah": "4444444444",
    "Rawan": "5555555555",
    "Faisal": "6666666666",
    "Layla": "7777777777"
}

# Prompt the user to input a phone number
phone_number = input("Enter a phone number: ")

# Check if the input is exactly 10 digits and contains only numbers
if len(phone_number) != 10 or not phone_number.isdigit():
    print("This is an invalid number")  # Print if the input is invalid
else:
    # Search for the number in the directory
    found = False  # A flag to indicate if the number is found
    for name, number in phone_directory.items():
        if number == phone_number:
            print(f"The number belongs to {name}")  # Print the owner's name
            found = True
            break  # Exit the loop once a match is found

    if not found:
        print("Sorry, the number is not found")  # If no match is found
